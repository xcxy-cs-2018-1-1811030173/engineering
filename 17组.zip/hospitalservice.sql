/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80016
 Source Host           : localhost:3306
 Source Schema         : hospitalservice

 Target Server Type    : MySQL
 Target Server Version : 80016
 File Encoding         : 65001

 Date: 10/05/2021 09:04:36
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for _order
-- ----------------------------
DROP TABLE IF EXISTS `_order`;
CREATE TABLE `_order`  (
  `orderId` int(11) NOT NULL AUTO_INCREMENT,
  `orderName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `orderCreatTime` date NOT NULL COMMENT '创建时间',
  `orderEndTime` date NOT NULL COMMENT '配送结束时间',
  `oederAddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '目标地址',
  `orderUserTel` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '配送目标号码',
  `orderBusinessTel` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商家号码',
  `orderStatus` int(11) NOT NULL COMMENT '实时更新物流状态',
  `userId` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`orderId`, `orderUserTel`, `orderStatus`, `userId`) USING BTREE,
  INDEX `userId`(`userId`) USING BTREE,
  INDEX `orderBusinessTel`(`orderBusinessTel`) USING BTREE,
  INDEX `orderStatus`(`orderStatus`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of _order
-- ----------------------------
INSERT INTO `_order` VALUES (20, '这是订单测试', '2021-04-15', '2021-04-23', '测地址', '123456', '0003', 3, '00012');
INSERT INTO `_order` VALUES (21, '这是订单测试', '2021-04-23', '2021-04-26', '测试地址2', '125000', '0002', 6, '10086');

-- ----------------------------
-- Table structure for _user
-- ----------------------------
DROP TABLE IF EXISTS `_user`;
CREATE TABLE `_user`  (
  `userIdTel` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '电话作为Id作为主键',
  `userName` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `userGender` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户名',
  `userPassword` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '密码',
  `userBirthDate` date NOT NULL COMMENT '出生日期',
  `userid` int(10) NULL DEFAULT NULL,
  PRIMARY KEY (`userIdTel`, `userName`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of _user
-- ----------------------------
INSERT INTO `_user` VALUES ('123', 'wangwu', '0', 'aaa', 'bbb', '2021-01-01', NULL);
INSERT INTO `_user` VALUES ('123456', 'zhansan', '1', '123@.com', '1234', '2021-04-18', 1);

-- ----------------------------
-- Table structure for advise
-- ----------------------------
DROP TABLE IF EXISTS `advise`;
CREATE TABLE `advise`  (
  `adviseId` int(11) NOT NULL,
  `adviseUserId` int(11) NOT NULL,
  `advisedoctorId` int(11) NOT NULL,
  `adviseTitle` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `adviseContent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`adviseUserId`, `advisedoctorId`, `adviseId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of advise
-- ----------------------------

-- ----------------------------
-- Table structure for adviser
-- ----------------------------
DROP TABLE IF EXISTS `adviser`;
CREATE TABLE `adviser`  (
  `adviserId` int(11) NOT NULL AUTO_INCREMENT,
  `adviseUserID` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `adviserDoctorID` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `adviseTitle` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `adviseContent` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`adviserId`, `adviseUserID`, `adviserDoctorID`) USING BTREE,
  INDEX `adviseUserID`(`adviseUserID`) USING BTREE,
  INDEX `adviserDoctorID`(`adviserDoctorID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of adviser
-- ----------------------------
INSERT INTO `adviser` VALUES (1, '123', '123456', '医疗问诊过程的评价', '这是一个超级好的医生，会唱会跳');
INSERT INTO `adviser` VALUES (2, '123456', '0002', '医疗评价', '这老师非常活泼聪明，是小有名气的医生，服务非常到位');

-- ----------------------------
-- Table structure for answer
-- ----------------------------
DROP TABLE IF EXISTS `answer`;
CREATE TABLE `answer`  (
  `answerID` int(11) NOT NULL AUTO_INCREMENT,
  `answerTitle` int(11) NOT NULL,
  `answere1` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `answer2` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `answer3` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `answer4` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `answer5` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `answer6` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `answer7` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `answer8` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`answerID`, `answerTitle`) USING BTREE,
  INDEX `title`(`answerTitle`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of answer
-- ----------------------------
INSERT INTO `answer` VALUES (4, 4, '答案1', '答案2', '答案3', '答案4', NULL, NULL, NULL, NULL);
INSERT INTO `answer` VALUES (5, 5, '答案1', '答案2', '答案3', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `answer` VALUES (6, 6, '答案1', '答案2', NULL, NULL, NULL, NULL, NULL, NULL);

-- ----------------------------
-- Table structure for doctor
-- ----------------------------
DROP TABLE IF EXISTS `doctor`;
CREATE TABLE `doctor`  (
  `doctorIdTel` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `doctorName` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `doctorGender` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `doctor` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `doctorPassword` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `doctorBirtheDate` date NOT NULL,
  `doctorOrder` int(11) NULL DEFAULT NULL,
  `doctorClassify` int(11) NOT NULL,
  `doctorTest` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`doctorIdTel`) USING BTREE,
  INDEX `doctorOrder`(`doctorOrder`) USING BTREE,
  INDEX `doctor_ibfk_3`(`doctorTest`) USING BTREE,
  INDEX `doctor_ibfk_2`(`doctorClassify`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of doctor
-- ----------------------------
INSERT INTO `doctor` VALUES ('0001', 'zhangsan', '男', 'wan_com', '124xx', '2021-04-01', 21, 8, 1);
INSERT INTO `doctor` VALUES ('0002', 'wangwu', '女', 'zhao_com', 'xiao123', '2021-04-15', 21, 9, 1);
INSERT INTO `doctor` VALUES ('0003', 'zhaoliu', '男', 'hua_com', '2156', '2021-04-08', 21, 10, 1);
INSERT INTO `doctor` VALUES ('0005', 'mmmm', '男', 'user_@.com', '1234567', '2021-01-01', NULL, 21, 8);
INSERT INTO `doctor` VALUES ('123456', 'lisi', '男', 'cai_com', '1234', '2021-04-25', 21, 7, 1);

-- ----------------------------
-- Table structure for doctordepartment
-- ----------------------------
DROP TABLE IF EXISTS `doctordepartment`;
CREATE TABLE `doctordepartment`  (
  `classifyId` int(11) NOT NULL AUTO_INCREMENT,
  `className` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `classFunction` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`classifyId`, `className`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of doctordepartment
-- ----------------------------
INSERT INTO `doctordepartment` VALUES (7, '脑科', '大脑');
INSERT INTO `doctordepartment` VALUES (8, '妇科', NULL);
INSERT INTO `doctordepartment` VALUES (9, '儿科', NULL);
INSERT INTO `doctordepartment` VALUES (10, '眼科', NULL);

-- ----------------------------
-- Table structure for mutlorder
-- ----------------------------
DROP TABLE IF EXISTS `mutlorder`;
CREATE TABLE `mutlorder`  (
  `multOrdreID` int(11) NOT NULL AUTO_INCREMENT,
  `multUserId` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `multOrderId` int(11) NOT NULL,
  PRIMARY KEY (`multOrdreID`, `multUserId`, `multOrderId`) USING BTREE,
  INDEX `multUserId`(`multUserId`) USING BTREE,
  INDEX `multOrderId`(`multOrderId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of mutlorder
-- ----------------------------
INSERT INTO `mutlorder` VALUES (6, '00012', 20);
INSERT INTO `mutlorder` VALUES (7, '10086', 21);

-- ----------------------------
-- Table structure for orderstatus
-- ----------------------------
DROP TABLE IF EXISTS `orderstatus`;
CREATE TABLE `orderstatus`  (
  `orderStatusID` int(11) NOT NULL AUTO_INCREMENT,
  `orderSrarusName` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`orderStatusID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of orderstatus
-- ----------------------------
INSERT INTO `orderstatus` VALUES (1, '订单初始化状态');
INSERT INTO `orderstatus` VALUES (2, '订单已创建状态');
INSERT INTO `orderstatus` VALUES (3, '订单已支付状态');
INSERT INTO `orderstatus` VALUES (4, '商品出库状态');
INSERT INTO `orderstatus` VALUES (5, '商品运输状态');
INSERT INTO `orderstatus` VALUES (6, '商品已抵达状态');
INSERT INTO `orderstatus` VALUES (7, '商品待签收状态');
INSERT INTO `orderstatus` VALUES (8, '商品已签收状态');
INSERT INTO `orderstatus` VALUES (10, '商品已经评价状态');
INSERT INTO `orderstatus` VALUES (11, 'heello');

-- ----------------------------
-- Table structure for test
-- ----------------------------
DROP TABLE IF EXISTS `test`;
CREATE TABLE `test`  (
  `testId` int(11) NOT NULL AUTO_INCREMENT,
  `testName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `testClassify` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `testDoctor` varchar(22) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`testId`, `testClassify`, `testDoctor`) USING BTREE,
  INDEX `doctor`(`testDoctor`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of test
-- ----------------------------
INSERT INTO `test` VALUES (1, 'ee', 'ee', 'ee');
INSERT INTO `test` VALUES (5, '问卷1', '测试一', '0001');
INSERT INTO `test` VALUES (8, '问卷2', '测试二', '0003');

-- ----------------------------
-- Table structure for title
-- ----------------------------
DROP TABLE IF EXISTS `title`;
CREATE TABLE `title`  (
  `titleId` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `test` int(11) NOT NULL,
  PRIMARY KEY (`titleId`, `test`) USING BTREE,
  INDEX `test`(`test`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of title
-- ----------------------------
INSERT INTO `title` VALUES (4, '问题1', 5);
INSERT INTO `title` VALUES (5, '问题2', 5);
INSERT INTO `title` VALUES (6, '问题3', 5);
INSERT INTO `title` VALUES (7, '问题4', 8);
INSERT INTO `title` VALUES (8, '问题5', 8);

-- ----------------------------
-- View structure for doctor_dept
-- ----------------------------
DROP VIEW IF EXISTS `doctor_dept`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `doctor_dept` AS select `doctor`.`doctorIdTel` AS `doctorIdTel`,`doctor`.`doctorName` AS `doctorName`,`doctor`.`doctorGender` AS `doctorGender`,`doctor`.`doctor` AS `doctor`,`doctor`.`doctorPassword` AS `doctorPassword`,`doctor`.`doctorBirtheDate` AS `doctorBirtheDate`,`doctor`.`doctorOrder` AS `doctorOrder`,`doctor`.`doctorClassify` AS `doctorClassify`,`doctor`.`doctorTest` AS `doctorTest`,`doctordepartment`.`classifyId` AS `classifyId`,`doctordepartment`.`className` AS `className`,`doctordepartment`.`classFunction` AS `classFunction` from (`doctordepartment` left join `doctor` on((`doctor`.`doctorClassify` = `doctordepartment`.`classifyId`)));

-- ----------------------------
-- View structure for select_user_order
-- ----------------------------
DROP VIEW IF EXISTS `select_user_order`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `select_user_order` AS select `_user`.`userIdTel` AS `userIdTel`,`_user`.`userName` AS `userName`,`_user`.`userGender` AS `userGender`,`_user`.`user` AS `user`,`_user`.`userPassword` AS `userPassword`,`_user`.`userBirthDate` AS `userBirthDate`,`_order`.`orderId` AS `orderId`,`_order`.`orderName` AS `orderName`,`_order`.`orderCreatTime` AS `orderCreatTime`,`_order`.`orderEndTime` AS `orderEndTime`,`_order`.`oederAddress` AS `oederAddress`,`_order`.`orderUserTel` AS `orderUserTel`,`_order`.`orderBusinessTel` AS `orderBusinessTel`,`_order`.`orderStatus` AS `orderStatus`,`_order`.`userId` AS `userId` from (`_order` left join `_user` on((`_user`.`userIdTel` = `_order`.`userId`)));

-- ----------------------------
-- View structure for selectdoctor_test
-- ----------------------------
DROP VIEW IF EXISTS `selectdoctor_test`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `selectdoctor_test` AS select `test`.`testId` AS `testId`,`test`.`testName` AS `testName`,`test`.`testClassify` AS `testClassify`,`test`.`testDoctor` AS `testDoctor`,`doctor`.`doctorIdTel` AS `doctorIdTel`,`doctor`.`doctorName` AS `doctorName`,`doctor`.`doctorGender` AS `doctorGender`,`doctor`.`doctor` AS `doctor`,`doctor`.`doctorPassword` AS `doctorPassword`,`doctor`.`doctorBirtheDate` AS `doctorBirtheDate`,`doctor`.`doctorOrder` AS `doctorOrder`,`doctor`.`doctorClassify` AS `doctorClassify`,`doctor`.`doctorTest` AS `doctorTest` from (`test` left join `doctor` on((`doctor`.`doctorIdTel` = `test`.`testDoctor`)));

-- ----------------------------
-- View structure for selecttest_title_anser
-- ----------------------------
DROP VIEW IF EXISTS `selecttest_title_anser`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `selecttest_title_anser` AS select `test`.`testId` AS `testId`,`test`.`testName` AS `testName`,`test`.`testClassify` AS `testClassify`,`test`.`testDoctor` AS `testDoctor`,`title`.`titleId` AS `titleId`,`title`.`title` AS `title`,`title`.`test` AS `test`,`answer`.`answerID` AS `answerID`,`answer`.`answerTitle` AS `answerTitle`,`answer`.`answere1` AS `answere1`,`answer`.`answer2` AS `answer2`,`answer`.`answer3` AS `answer3`,`answer`.`answer4` AS `answer4`,`answer`.`answer5` AS `answer5`,`answer`.`answer6` AS `answer6`,`answer`.`answer7` AS `answer7`,`answer`.`answer8` AS `answer8` from (`answer` left join (`title` left join `test` on((`test`.`testId` = `title`.`test`))) on((`title`.`titleId` = `answer`.`answerTitle`)));

-- ----------------------------
-- View structure for seltorder_seletdoctor
-- ----------------------------
DROP VIEW IF EXISTS `seltorder_seletdoctor`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `seltorder_seletdoctor` AS select `_order`.`orderId` AS `orderId`,`_order`.`orderName` AS `orderName`,`_order`.`orderCreatTime` AS `orderCreatTime`,`_order`.`orderEndTime` AS `orderEndTime`,`_order`.`oederAddress` AS `oederAddress`,`_order`.`orderUserTel` AS `orderUserTel`,`_order`.`orderBusinessTel` AS `orderBusinessTel`,`_order`.`orderStatus` AS `orderStatus`,`_order`.`userId` AS `userId`,`doctor`.`doctorIdTel` AS `doctorIdTel`,`doctor`.`doctorName` AS `doctorName`,`doctor`.`doctorGender` AS `doctorGender`,`doctor`.`doctor` AS `doctor`,`doctor`.`doctorPassword` AS `doctorPassword`,`doctor`.`doctorBirtheDate` AS `doctorBirtheDate`,`doctor`.`doctorOrder` AS `doctorOrder`,`doctor`.`doctorClassify` AS `doctorClassify`,`doctor`.`doctorTest` AS `doctorTest` from (`doctor` left join `_order` on((`_order`.`orderBusinessTel` = `doctor`.`doctorIdTel`)));

-- ----------------------------
-- Triggers structure for table _order
-- ----------------------------
DROP TRIGGER IF EXISTS `insert_order`;
delimiter ;;
CREATE TRIGGER `insert_order` AFTER INSERT ON `_order` FOR EACH ROW BEGIN
    /*if((select userIdTel from _user where userIdTel=123)){ };*/
  /*  update mutlOrder set multUserID=new.orderId where userIdTel=new.userId;*/
   iNSERT INTO mutlOrder(multUserId,multOrderId)values(new.userId,new.orderId);
   update doctor set doctorOrder=new.orderId;
    END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table doctor
-- ----------------------------
DROP TRIGGER IF EXISTS `delete_doctor`;
delimiter ;;
CREATE TRIGGER `delete_doctor` AFTER DELETE ON `doctor` FOR EACH ROW BEGIN
	SET FOREIGN_KEY_CHECKS=0;
	DELETE FROM test WHERE doctor=old.doctorIdTel;
	SET FOREIGN_KEY_CHECKS=1;
    END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table mutlorder
-- ----------------------------
DROP TRIGGER IF EXISTS `delet_mult_user`;
delimiter ;;
CREATE TRIGGER `delet_mult_user` AFTER DELETE ON `mutlorder` FOR EACH ROW BEGIN
	SET FOREIGN_KEY_CHECKS=0;
	DELETE FROM  _order WHERE orderId=old.multOrderId;
	SET FOREIGN_KEY_CHECKS=1;
    END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table test
-- ----------------------------
DROP TRIGGER IF EXISTS `insert_test`;
delimiter ;;
CREATE TRIGGER `insert_test` AFTER INSERT ON `test` FOR EACH ROW BEGIN
	update doctor set doctorTest=new.testId;
    END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table test
-- ----------------------------
DROP TRIGGER IF EXISTS `delete_test`;
delimiter ;;
CREATE TRIGGER `delete_test` AFTER DELETE ON `test` FOR EACH ROW BEGIN
		SET FOREIGN_KEY_CHECKS=0;
	DELETE FROM title WHERE test=old.testId;
	SET FOREIGN_KEY_CHECKS=1;
    END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table title
-- ----------------------------
DROP TRIGGER IF EXISTS `delete_title`;
delimiter ;;
CREATE TRIGGER `delete_title` AFTER DELETE ON `title` FOR EACH ROW BEGIN
	SET FOREIGN_KEY_CHECKS=0;
	DELETE FROM answer WHERE title=old.titleId;
	SET FOREIGN_KEY_CHECKS=1;
    END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
